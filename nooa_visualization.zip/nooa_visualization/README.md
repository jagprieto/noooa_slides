noooa_slides
============
NOOA Strom database visualizer presentation.
